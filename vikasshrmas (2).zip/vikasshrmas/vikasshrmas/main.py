import pickle
from flask import Flask, render_template, request
import numpy as np



# load the  ml model 
with open("knnClassifer.pkl",'rb') as out:
    model = pickle.load(out)

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("base.html")

@app.route("/prediction", methods=['GET',"POST"])
def predict():
    if request.method == "POST":
        gender = request.form['gender']
        print("gender:",gender)
        ssc_b = request.form['ssc_b']
        print("ssc_b:",ssc_b)
        hsc_b = request.form['hsc_b']
        print("hsc_b:",hsc_b)
        hsc_s = request.form['hsc_s']
        print("hsc_1:",hsc_s)
        degree_t = request.form['degree_t']
        # print("degree_t:",degree_t)
        workex1 = request.form['workex1']
        # print("workex1:",workex1)
        specialisation = request.form['specialisation']
        ssc_p = request.form['ssc_p']
        hsc_p = request.form['hsc_p']
        degree_p = request.form['degree_p']
        etest = request.form['etest']
        salary = request.form['salary']
        mba_p = request.form['mba_p']
        print(salary, etest, ssc_p,hsc_p,specialisation,workex1,degree_t)

        if ssc_b == 'central':
            ssc_b = 2
        else:
            ssc_b = 1
        if hsc_b == 'central':
            hsc_b = 2
        else:
            hsc_b = 1
        if gender == 'male':
            gender = 1
        else:
            gender = 2

        if degree_t == 'sciandtech':
            degree_t1 = 2
        elif degree_t == 'commandmng':
            degree_t1 = 1
        else:
            degree_t1 = 3 
    
        if workex1 == 'yes':
            workex1 = 1
        else:
            workex1 = 2
        
        if hsc_s == 'commerce':
            hsc_s1 = 2
        elif hsc_s == 'science':
            hsc_s1 = 1
        else:
            hsc_s1 = 3
        
        if specialisation == 'mkandhr':
            specialisation1 = 2
        else:
            specialisation1 = 1
    
        Pred_args=[gender,int(ssc_p),ssc_b,int(hsc_p),hsc_b,hsc_s1,int(degree_p),degree_t1,workex1,int(etest),specialisation1,int(mba_p), int(salary)]
        pred_args=np.array(Pred_args)
        pred_args=pred_args.reshape(1,-1)
        
        y_pred=model.predict(pred_args)
        if y_pred == 0:
            return render_template('output.html',res="Work Hard!!! Chances are less") 
        else:
            return render_template('output.html',res="You are Doing well!! You Will Get placements")
    
    return render_template("predict.html")
   
    
    



if __name__ == '__main__':
    app.run()